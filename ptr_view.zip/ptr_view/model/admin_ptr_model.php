<?php
class Admin_ptr_model extends CI_Model
{
	function ptr_view_total()
	{
		$query=$this->db->get('ptr');
		
		if($query->num_rows > 0)
			return $query->num_rows();
		else
			return false;

		
	}
	
	
	function active_selection($ptr_sel_status)
	{
		$this->db->select('*');
		$this->db->from('ptr');
		//$this->db->limit($limit,$start);
		
		if($ptr_sel_status == "1")
			$this->db->like('active',$ptr_sel_status,'none');
		
		else if($ptr_sel_status == "2")
			$this->db->not_like('active', '1');
			
		$query=$this->db->get();
			
			if($query->num_rows > 0)
			return $query->result_array();
			
	}
	function ptr_status()
	{
			$query=$this->db->get("doc_status");
			
			if($query->num_rows > 0)
			return $query->result_array();
			
			else
			return false;
	}
	
	function ptr_view($ptr_sel_status)
	{
		$this->db->select('*');
		$this->db->from('ptr');
		//$this->db->limit($limit,$start);
		
		if($ptr_sel_status == "1")
			$this->db->like('active',$ptr_sel_status,'none');
		
		else if($ptr_sel_status == "2")
			$this->db->not_like('active', '1');
			
		$query=$this->db->get();
		if($query->num_rows > 0)
			return $query->result_array();
		else
			return false;
	}

	function ptr_profile($ptr_id)
	{
		$ptr_biz=$this->db->get_where('ptr_biz',array('ptr_id'=>$ptr_id));
		
		if($ptr_biz->num_rows > 0)
		{
			//echo "hi";
			$this->db->select('*,ptr.pic as ptr_pic');
			$this->db->from('ptr');
			//$this->db->join('ptr_doc_upload as ptr_doc','ptr.ptr_id=ptr_doc.ptr_id');
			$this->db->join('ptr_biz','ptr.ptr_id=ptr_biz.ptr_id');
			$this->db->where('ptr.ptr_id',$ptr_id);
			$query=$this->db->get();
			
			if($query->num_rows > 0)
				return $query->row();
			else
				return false;
		}
		else
		{
			//echo "bye";
			$this->db->select('*,ptr.pic as ptr_pic');
			$this->db->from('ptr');
			//$this->db->join('ptr_doc_upload as ptr_doc','ptr.ptr_id=ptr_doc.ptr_id');
			$this->db->where('ptr.ptr_id',$ptr_id);
			$query=$this->db->get();
			
			if($query->num_rows > 0)
				return $query->row();
			else
				return false;
		}
			
		
	}
	
	function ptr_docs($ptr_id)
	{
		$array=array('doc_up.ptr_id'=>$ptr_id);
		$this->db->select('*');
		$this->db->from('ptr_doc_upload as doc_up');
		$this->db->join('ptr_doc','ptr_doc.ptr_doc_id=doc_up.ptr_doc_id','left');
		$this->db->where($array);
		$query=$this->db->get();

		if($query->num_rows > 0)
				return $query->result_array();
			else
				return false;
	
	}
	
	function ptr_change_status($rad_val,$rad_class)
	{
		$array=array('doc_status_id'=>$rad_val);
		$this->db->where( 'ptr_doc_upload_id',$rad_class);
		$query=$this->db->update('ptr_doc_upload',$array);
		if($query)
			echo 200;
		else
			echo 404;
	}
	
	function ptr_main_status($chk_val,$ptr_id)
	{
		if($chk_val == 0):
			$my_query='SELECT * FROM (`ptr_doc_upload`) WHERE `ptr_id` = '.$ptr_id.' AND (`doc_status_id` = 2 OR `doc_status_id` = 3)';
			$query=$this->db->query($my_query);
			/*$query=$this->db->select('*');
			$query=$this->db->from('ptr_doc_upload1');
			$query=$this->db->where('ptr_id', $ptr_id);
			$query=$this->db->and_where('doc_status_id', '2');
			$query=$this->db->or_where('doc_status_id','3');
			$query=$this->db->get();
			*/
			if($query->num_rows > 0):
				echo 2;
			
			else:
				$array=array('active'=>'1');
				$this->db->where('ptr_id',$ptr_id);
				$this->db->update('ptr',$array);
			echo 1;
			
			endif;
		else:
			$array=array('active'=>'0');
			$this->db->where('ptr_id',$ptr_id);
			$this->db->update('ptr',$array);
			
			echo  3;
		
		endif;	
		
			
			
	}
	
	function drv_select_status()
	{
		$query=$this->db->get('doc_status');
		if($query->num_rows > 0)
		{
			return $query->result_array();
		}
		else
		{
			return false;
		}
	}
	
	
	function drv_profile($ptr_id)
	{
//echo "hi";
			$this->db->select('*,drv.ptr_id as ptr_code,drv.pic as drv_pic,doc_up.drv_id as my_drv_id,drv.active as drv_active');
			$this->db->from('drv');
			$this->db->join('drv_doc_upload as doc_up','drv.drv_id = doc_up.drv_id','left');		
			//$this->db->join('doc_status','drv_doc_upload.doc_status_id = doc_status.doc_status_id','left');
			$this->db->join('drv_doc','drv_doc.drv_doc_id=doc_up.drv_doc_id','left');
			$this->db->join('drv_test_result','drv_test_result.drv_id = drv.drv_id','left');

			$this->db->where('drv.ptr_id',$ptr_id);
			//$this->db->limit($limit,$start);

			/*if($id != 'all')
			{
				$this->db->like('doc_up.doc_status_id',$id,'none');

			}
			else
			$this->db->like('doc_up.doc_status_id','','before');
			*/
			$this->db->order_by('drv.reg_date','desc');

			$this->db->group_by('doc_up.drv_id');	

			 $query=$this->db->get();
				
		if($query->num_rows > 0)
		{
			return $query->result_array();
		}
		else
		{
			return false;
		}
		
	}
	
	function GetDrvDocs($drv_id)
	{
		$this->db->select('*,drv.ptr_id as ptr_code,drv.pic as drv_pic,doc_up.drv_id as my_drv_id,drv.active as drv_active');
		$this->db->from('drv');
		//$this->db->from("drv_doc_upload as doc_upd");
		$this->db->join('drv_doc_upload as doc_up','drv.drv_id = doc_up.drv_id','left');		
		$this->db->join('drv_doc','drv_doc.drv_doc_id=doc_up.drv_doc_id','left');
		$this->db->where("doc_up.drv_id",$drv_id);
		//$this->db->group_by('doc_up.drv_id');	
		 $query=$this->db->get();
				
		if($query->num_rows > 0)
		{
			echo json_encode($query->result_array());
		}
		else
		{
			echo false;
		}

		
	}
	
	function drv_change_status($rad_val,$rad_class)
	{
		$array=array('doc_status_id'=>$rad_val);
		$this->db->where( 'drv_doc_upload_id',$rad_class);
		$query=$this->db->update('drv_doc_upload',$array); //update document status id
		
		if($this->input->get_post('reason') and $this->input->get_post('reason') != "") //insert documents rejection reason
		{	
			$reason=$this->input->get_post('reason');
			$reg_date=$this->input->get_post('reg_date');
			$array2=array('reason'=>$reason,'drv_doc_upload_id'=>$rad_class,'reg_date'=>$reg_date);
			
			$query=$this->db->insert('drv_doc_rejected',$array2);
		}
		
		else
		{
			$select=$this->db->get_where('drv_doc_rejected',array('drv_doc_upload_id'=>$rad_class));
			
			if($select->num_rows > 0)
			{
				$this->db->delete('drv_doc_rejected',array('drv_doc_upload_id'=>$rad_class));
			}	
		}
		if($query)
			echo 200;
		else
			echo 404;
	}
	
	
	function drv_main_status($chk_val,$drv_id)
	{
		if($chk_val == 0):
			$my_query='SELECT * FROM (`drv_doc_upload`) WHERE `drv_id` = '.$drv_id.' AND (`doc_status_id` = 2 OR `doc_status_id` = 3)';
			$query=$this->db->query($my_query);
			/*$query=$this->db->select('*');
			$query=$this->db->from('ptr_doc_upload1');
			$query=$this->db->where('ptr_id', $ptr_id);
			$query=$this->db->and_where('doc_status_id', '2');
			$query=$this->db->or_where('doc_status_id','3');
			$query=$this->db->get();
			*/
			if($query->num_rows > 0):
				echo 2;
			
			else:
				$array=array('active'=>'1');
				$this->db->where('drv_id',$drv_id);
				$this->db->update('drv',$array);
			echo 1;
			
			endif;
		else:
			$array=array('active'=>'0');
			$this->db->where('drv_id',$drv_id);
			$this->db->update('drv',$array);
			
			echo  3;
		
		endif;	
		
			
			
	}
	
	function drv_doc_status($drv_id)
	{
		$array=array('drv_id'=> $drv_id , 'doc_status_id'=>'2');
		$array2=array('doc_upd.drv_id'=> $drv_id , 'doc_upd.doc_status_id'=>'1', 'drv.active'=>'1');
		$this->db->select('*');
		$this->db->from('drv_doc_upload');
		$this->db->where($array);
		$query=$this->db->get();
		if($query->num_rows >= 1)
		{	return '2'; }
		else
		{
			$this->db->select('*');
			$this->db->from('drv_doc_upload as doc_upd');
			$this->db->join('drv','drv.drv_id=doc_upd.drv_id');
			$this->db->where($array2);
			$query=$this->db->get();
				if($query->num_rows >= 1)
					return '1';
				else
					return '3';
		}
	}
	
	
	function vhl_profile($ptr_id)
	{
		$array=array('vhl.ptr_id'=>$ptr_id);
		$this->db->select('*,doc_up.vhl_id as my_vhl_id,srv.name as srv_name,vehicle.name AS vhl_name, vehicle_model.name AS vhl_mdl, vhl.lic_plate AS lic_plate, vhl.lic_plate_country AS lic_plate_country, vhl.lic_plate_state AS lic_plate_state, vhl.in_color AS in_color, vhl.ex_color AS ex_color, vhl.active AS vhl_active, vhl.reg_date AS reg_date,vhl_doc.name as vhl_doc_name');
		$this->db->from('srv');
		$this->db->join('vehicle','srv.srv_id = vehicle.srv_id');
		$this->db->join('vehicle_model','vehicle_model.vehicle_id = vehicle.vehicle_id');
		$this->db->join('vhl','vehicle_model.model_id = vhl.model_id');
		$this->db->join('vhl_doc_upload as doc_up','vhl.vhl_id = doc_up.vhl_id','left');		
		//$this->db->join('doc_status','drv_doc_upload.doc_status_id = doc_status.doc_status_id','left');
		$this->db->join('vhl_doc','vhl_doc.vhl_doc_id=doc_up.vhl_doc_id','left');
		$this->db->where($array);
		
		$query=$this->db->get();
					
		if($query->num_rows > 0)
		{
			return $query->result_array();
		}
		else
		{
			return false;
		}
		
	}
	
	function GetVhlDocs($vhl_id)
	{
		$array=array('vhl.vhl_id'=>$vhl_id);
		$this->db->select('*,doc_up.vhl_id as my_vhl_id,srv.name as srv_name,vehicle.name AS vhl_name, vehicle_model.name AS vhl_mdl, vhl.lic_plate AS lic_plate, vhl.lic_plate_country AS lic_plate_country, vhl.lic_plate_state AS lic_plate_state, vhl.in_color AS in_color, vhl.ex_color AS ex_color, vhl.active AS vhl_active, vhl.reg_date AS reg_date,vhl_doc.name as vhl_doc_name');
		$this->db->from('srv');
		$this->db->join('vehicle','srv.srv_id = vehicle.srv_id');
		$this->db->join('vehicle_model','vehicle_model.vehicle_id = vehicle.vehicle_id');
		$this->db->join('vhl','vehicle_model.model_id = vhl.model_id');
		$this->db->join('vhl_doc_upload as doc_up','vhl.vhl_id = doc_up.vhl_id','left');		
		//$this->db->join('doc_status','drv_doc_upload.doc_status_id = doc_status.doc_status_id','left');
		$this->db->join('vhl_doc','vhl_doc.vhl_doc_id=doc_up.vhl_doc_id','left');
		$this->db->where($array);
		
		$query=$this->db->get();
					
		if($query->num_rows > 0)
		{
			//print_r($query->result_array());
			echo json_encode($query->result_array());
		}
		else
		{
			echo false;
		}
		
	}
	
	
	function vhl_change_status($rad_val,$rad_class)
	{
		$array=array('doc_status_id'=>$rad_val);
		$this->db->where( 'vhl_doc_upload_id',$rad_class);
		$query=$this->db->update('vhl_doc_upload',$array);
		if($query)
			echo 200;
		else
			echo 404;
	}

	
	function vhl_main_status($chk_val,$vhl_id)
	{
		if($chk_val == 0):
			$my_query='SELECT * FROM (`vhl_doc_upload`) WHERE `vhl_id` = '.$vhl_id.' AND (`doc_status_id` = 2 OR `doc_status_id` = 3)';
			$query=$this->db->query($my_query);
			/*$query=$this->db->select('*');
			$query=$this->db->from('ptr_doc_upload1');
			$query=$this->db->where('ptr_id', $ptr_id);
			$query=$this->db->and_where('doc_status_id', '2');
			$query=$this->db->or_where('doc_status_id','3');
			$query=$this->db->get();
			*/
			if($query->num_rows > 0):
				echo 2;
			
			else:
				$array=array('active'=>'1');
				$this->db->where('vhl_id',$vhl_id);
				$this->db->update('vhl',$array);
			echo 1;
			
			endif;
		else:
			$array=array('active'=>'0');
			$this->db->where('vhl_id',$vhl_id);
			$this->db->update('vhl',$array);
			
			echo  3;
		
		endif;	
		
			
			
	}
}

?>