<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class AdminPtrAjaxModel extends CI_Model {


 public function GetPtrListForDataTable($ptr_sel_status) {
        $aColumns = array('p.ptr_id', 'p.fname', 'p.mname', 'p.lname', 'p.active');

        /* Indexed column (used for fast and accurate table cardinality) */
        $sIndexColumn = "p.ptr_id";

        /* DB table to use */
        $sTable = "ptr p";

			
        // Calling DataTableAble
		$output = $this->_MakeDataTableAble($aColumns, $sIndexColumn, $sTable,$ptr_sel_status);
        
        return $output;
    }
	
	protected function _MakeDataTableAble($aColumns, $sIndexColumn, $sTable,$ptr_sel_status) {
        /*
         * Paging
         */
        $sLimit = "";
        $piDisplayStart = $this->input->get('iDisplayStart');
        $piDisplayLength = $this->input->get('iDisplayLength');
        if ($piDisplayStart != '' && $piDisplayLength != '-1') {
            $sLimit = "LIMIT " . $this->db->escape_str($piDisplayStart) . ", " . $this->db->escape_str($piDisplayLength);
        }

        /*
         * Ordering
         */
        $sOrder = "";
        $piSortCol_0 = $this->input->get('iSortCol_0');
        if ($piSortCol_0 != '') {
            $sOrder = "ORDER BY  ";
            $piSortingCols = $this->input->get('iSortingCols');
            for ($i = 0; $i < intval($piSortingCols); $i++) {
                $piSortCol = intval($this->input->get('iSortCol_' . $i));
                $pibSortable = $this->input->get('bSortable_' . intval($piSortCol));
                if ($pibSortable == "true") {
                    //$sOrder .= "".$aColumns[ intval( $piSortCol )-1 ]." ".
                    $sOrder .= "" . $this->input->get('mDataProp_' . intval($piSortCol)) . " " .
                            $this->db->escape_str($this->input->get('sSortDir_' . $i)) . ", ";
                }
            }

            $sOrder = substr_replace($sOrder, "", -2);
            if ($sOrder == "ORDER BY" or $sOrder == "ORDER BY  ") {
                $sOrder = "";
            }
        }
	
	
	
	 /*
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        $sWhere = "";
        $psSearch = $this->input->get('sSearch');
        if ($psSearch != '' && $this->input->get('sSearch') != "") {
            $sWhere = "WHERE (";
            for ($i = 0; $i < count($aColumns); $i++) {
                $sWhere .= "" . $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($this->input->get('sSearch')) . "%' OR ";
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= ')';
        }

        /* Individual column filtering */
        for ($i = 0; $i < count($aColumns); $i++) {
            $pbSearchable = $this->input->get('bSearchable_' . $i);
            if ($pbSearchable != '' && $this->input->get('bSearchable_' . $i) == "true" && $this->input->get('sSearch_' . $i) != '') {
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
                $sWhere .= "" . $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($this->input->get('sSearch_' . $i)) . "%' ";
            }
        }

		/* where condition 
		if($ptr_sel_status != Null)
		{
			if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
			if($ptr_sel_status == 0)
				$sWhere.= "" . $aColumns[4] . " like '%'";
			else if($ptr_sel_status == 1)
				$sWhere.= "" . $aColumns[4] . " like ".$ptr_sel_status."";
			else if($ptr_sel_status == 2)
				$sWhere.= "" . $aColumns[4] . " not like '1'";
		}
		
*/
        /*
         * SQL queries
         * Get data to display
         */
        $sQuery = "
			SELECT SQL_CALC_FOUND_ROWS " . implode(" ,  ", $aColumns) . " ,
			DATE_FORMAT(p.reg_date, '%D %M %Y %h:%i %p') as reg_date
			
			FROM   $sTable
			$sWhere
			GROUP BY p.ptr_id
			$sOrder
			$sLimit
			";
        $rResult = $this->db->query($sQuery);

        /* Data set length after filtering */
        $sQuery = "
			SELECT FOUND_ROWS() as total_filtered_rows
		";
        $rResultFilterTotal = $this->db->query($sQuery);
        $aResultFilterTotal = $rResultFilterTotal->row_array();
        $iFilteredTotal = (isset($aResultFilterTotal['total_filtered_rows']) && $aResultFilterTotal['total_filtered_rows'] != '') ? $aResultFilterTotal['total_filtered_rows'] : 0;

        /* Total data set length */
        $sQuery = "
			SELECT COUNT(" . $sIndexColumn . ") as total_row
			FROM   $sTable
			$sWhere
		";
        $rResultTotal = $this->db->query($sQuery);
        $aResultTotal = $rResultTotal->row_array();
        $iTotal = (isset($aResultTotal['total_row']) && $aResultTotal['total_row'] != '') ? $aResultTotal['total_row'] : 0;


        /*
         * Output
         */
        $output = array(
            "sEcho" => intval($this->input->get('sEcho')),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array(),
			
        );

        $aRows = $rResult->result_array();

        $output['aaData'] = $aRows;
		

        /* foreach ($aRows as $aRow) {
          $row = array();
          for ($i = 0; $i < count($aColumns); $i++) {
          if ($aColumns[$i] != '') {
          /* General output */
        /* $row[] = $aRow[$aColumns[$i]];
          }
          }
          $output['aaData'] = $aRows;
          } */

        return $output;
    }
	
	function GetdrvListForDataTable()
	{
		$aColumns = array( 'd.drv_id ', 'd.fname', 'd.mname', 'd.lname','d.active','t.passed','d.email','d.dob','d.mobile','d.address','d.lic_no','doc.name','up.drv_doc_upload_id');

        /* Indexed column (used for fast and accurate table cardinality) */
        $sIndexColumn = "d.ptr_id";

        /* DB table to use */
        $sTable = "drv d 
						LEFT JOIN drv_doc_upload up 
						ON FIND_IN_SET(d.drv_id, up.drv_id)
						
						LEFT JOIN drv_doc doc 
						ON FIND_IN_SET(doc.drv_doc_id, up.drv_doc_id)
						
						LEFT JOIN drv_test_result t 
						ON FIND_IN_SET(d.drv_id, t.drv_id)
						";

        // Calling DataTableAble
		$output = $this->_MakeDataTableAbleForDrv($aColumns, $sIndexColumn, $sTable);
        
        return $output;
	}
	
	function _MakeDataTableAbleForDrv($aColumns, $sIndexColumn, $sTable)
	{
		 /*
         * Paging
         */
        $sLimit = "";
        $piDisplayStart = $this->input->get('iDisplayStart');
        $piDisplayLength = $this->input->get('iDisplayLength');
        if ($piDisplayStart != '' && $piDisplayLength != '-1') {
            $sLimit = "LIMIT " . $this->db->escape_str($piDisplayStart) . ", " . $this->db->escape_str($piDisplayLength);
        }

        /*
         * Ordering
         */
        $sOrder = "";
        $piSortCol_0 = $this->input->get('iSortCol_0');
        if ($piSortCol_0 != '') {
            $sOrder = "ORDER BY  ";
            $piSortingCols = $this->input->get('iSortingCols');
            for ($i = 0; $i < intval($piSortingCols); $i++) {
                $piSortCol = intval($this->input->get('iSortCol_' . $i));
                $pibSortable = $this->input->get('bSortable_' . intval($piSortCol));
                if ($pibSortable == "true") {
                    //$sOrder .= "".$aColumns[ intval( $piSortCol )-1 ]." ".
                    $sOrder .= "" . $this->input->get('mDataProp_' . intval($piSortCol)) . " " .
                            $this->db->escape_str($this->input->get('sSortDir_' . $i)) . ", ";
                }
            }

            $sOrder = substr_replace($sOrder, "", -2);
            if ($sOrder == "ORDER BY" or $sOrder == "ORDER BY  ") {
                $sOrder = "";
            }
        }
	
	
	
	 /*
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        $sWhere = "";
        $psSearch = $this->input->get('sSearch');
        if ($psSearch != '' && $this->input->get('sSearch') != "") {
            $sWhere = "WHERE (";
            for ($i = 0; $i < count($aColumns); $i++) {
                $sWhere .= "" . $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($this->input->get('sSearch')) . "%' OR ";
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= ')';
        }

        /* Individual column filtering */
        for ($i = 0; $i < count($aColumns); $i++) {
            $pbSearchable = $this->input->get('bSearchable_' . $i);
            if ($pbSearchable != '' && $this->input->get('bSearchable_' . $i) == "true" && $this->input->get('sSearch_' . $i) != '') {
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
                $sWhere .= "" . $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($this->input->get('sSearch_' . $i)) . "%' ";
            }
        }
		
		$ptr_id=$this->input->get_post('ptr_id');
		//get last week in where condition 
			if($ptr_id !="")
			{
				if ($sWhere == "") {
					$sWhere = "WHERE ";
				}else {
					$sWhere = " AND ";
				}	
				//$sWhere .= " YEARWEEK( t.trip_date, 1 ) = YEARWEEK( current_date - INTERVAL 1 week )";
				$sWhere .= " d.ptr_id = ".$ptr_id." ";
			}
			
		/* where condition 
		if($ptr_sel_status != Null)
		{
			if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
			if($ptr_sel_status == 0)
				$sWhere.= "" . $aColumns[4] . " like '%'";
			else if($ptr_sel_status == 1)
				$sWhere.= "" . $aColumns[4] . " like ".$ptr_sel_status."";
			else if($ptr_sel_status == 2)
				$sWhere.= "" . $aColumns[4] . " not like '1'";
		}
		
*/
        /*
		DATE_ADD( DATE( t.trip_date ) , INTERVAL( 7 - DAYOFWEEK( t.trip_date )  ) DAY ) as week_ending
         * SQL queries
         * Get data to display
         */
      
		$sQuery = "
			SELECT SQL_CALC_FOUND_ROWS " . implode(" ,  ", $aColumns) . " ,
			DATE_FORMAT(d.reg_date, '%D %M %Y %h:%i %p') as reg_date,
			d.ptr_id as ptr_code,d.pic as drv_pic,up.drv_id as my_drv_id,d.active as drv_active,
			GROUP_CONCAT(DISTINCT doc.name) AS name, GROUP_CONCAT(DISTINCT up.drv_doc_upload_id) AS drv_doc_upload_id,	
			GROUP_CONCAT(up.doc_status_id SEPARATOR ',') AS doc_status_id
			

		
			FROM   $sTable
			$sWhere
			group by up.drv_id
			$sOrder
			$sLimit
			";
        $rResult = $this->db->query($sQuery);

        /* Data set length after filtering */
        $sQuery = "
			SELECT FOUND_ROWS() as total_filtered_rows
		";
        $rResultFilterTotal = $this->db->query($sQuery);
        $aResultFilterTotal = $rResultFilterTotal->row_array();
        $iFilteredTotal = (isset($aResultFilterTotal['total_filtered_rows']) && $aResultFilterTotal['total_filtered_rows'] != '') ? $aResultFilterTotal['total_filtered_rows'] : 0;

        /* Total data set length */
        $sQuery = "
			SELECT COUNT(" . $sIndexColumn . ") as total_row
			FROM   $sTable
			$sWhere
		";
        $rResultTotal = $this->db->query($sQuery);
        $aResultTotal = $rResultTotal->row_array();
        $iTotal = (isset($aResultTotal['total_row']) && $aResultTotal['total_row'] != '') ? $aResultTotal['total_row'] : 0;


        /*
         * Output
         */
        $output = array(
            "sEcho" => intval($this->input->get('sEcho')),
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array(),
			
        );

        $aRows = $rResult->result_array();

        $output['aaData'] = $aRows;
		

        /* foreach ($aRows as $aRow) {
          $row = array();
          for ($i = 0; $i < count($aColumns); $i++) {
          if ($aColumns[$i] != '') {
          /* General output */
        /* $row[] = $aRow[$aColumns[$i]];
          }
          }
          $output['aaData'] = $aRows;
          } */

        return $output;
		
	}

	
	
}	
	?>