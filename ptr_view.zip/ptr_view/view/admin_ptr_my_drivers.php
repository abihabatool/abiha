
<style>
#datatable_length{
    font-size: 12px;
  padding-right: 0px; 
  float: right;
  padding-top: 12px;
}
#datatable_filter {
  padding-top: 0px;
}
</style>
<!--driver modal-->

<div class="modal-dialog" style="width:1025px"> 
<div class="modal-content">
<div class="modal-header"> 
<button type="button" class="close" data-dismiss="modal">&times;</button> 
<h4 class="modal-title">Driver Data</h4> 
</div>  
<div class="modal-body">

<section class="panel panel-default">
 <div class="row text-sm wrapper">
 <div class="col-sm-3"> 
 <div class="input-group"> 
 <input type="text" placeholder="Search" class="input-sm form-control"> 
 <span class="input-group-btn"> 
 <button type="button" class="bton btn-sm btn-default">Go!</button> 
 </span> 
 </div> 
 </div>

<div class="col-sm-5 m-b-xs">  
<select class="input-sm form-control input-s-sm inline" id="select_test_status"> 
<option value="">By Result</option> 
<option value="Failed">Failed</option> 
<option value="Passed">Passed</option>
 <option value="Not Attempted">Not Attempted</option> 
 </select>
 
 <select class="input-sm form-control input-s-sm inline" id="select_drv_status" > 
<option value="">Driver Status</option> 
<option value="Pending">Pending</option> 
<option value="Rejected">Rejected</option> 
<option value="Active">Accepted</option>
 </select>
 
 <select class="input-sm form-control input-s-sm inline" id="select_ActDeact_status"> 
<option value="">All</option> 
<option value="1">Active partner</option> 
<option value="0">De-Active partner</option>  
 </select>
 
 </div> 
 </div> 
  <input type="hidden" id="ptr_id" value="<?php echo $ptr_id; ?>">
  <div class="table-responsive"> 
  <table class="table table-striped table-bordered table-hover report" id="datatable" style="width:962px"> 
 <thead>
        <tr>
       	 	<th>S.No</th> 
       	 	<th>Status</th> 
       	 	<th>Name</th> 
       	 	<th>Test Result</th> 
       	 	<th>Status</th> 
           
           
        </tr>
        </thead>
			<tbody>
			   
       </tbody>     
		
      
        
    </table>
  
  
  
  </div>
  </section>
  
  </div> 

</div>
</div>
<!-- /.modal-dialog -->


<!-- /driver modal-->

 
<!-- /.modal --> 
  
  
  
  
<!-- Scripting Start -->

<!--Main js-->

<!--Table Toggle js--> 
<script type="text/javascript" cache="false" asyn="false">  
$(document).ready(function() {
        var anOpen = [];
        var mTable;
        var sImageUrl = "http://datatables.net/examples/resources/";
		var status;
        /*var search = "";
         if ( window.location.hash !== "" ) {
         search = window.location.hash.substring( 1 );
         }*/

       var mTable=$('#datatable').dataTable({   //datatable start
        //"bJQueryUI": true,
		"processing": true,
        "serverSide": true,
        'sPaginationType':'full_numbers',
		"bSort" : false,
		"aaSorting": [[ 2, 'asc' ]],
		 "bProcessing": true,
            "bServerSide": true,
            "oLanguage": {
                "sLengthMenu": "_MENU_ per page",
                "oPaginate": {
                    "sPrevious": "Prev",
                    "sNext": "Next"
                }
            },
            "bJQueryUI": true,
                    "sAjaxSource": "<?php echo base_url();?>index.php/su/admin_ptr_view/getdrvlistajax",
            "fnServerParams": function ( aoData ) {
				aoData.push({"name": "ptr_id", "value": $("#ptr_id").val() });


       },
			
		
            "aoColumns": [
              
                {
                    "mDataProp": null,
                    "sClass": "sno usersImage hidden-480",
                    "sDefaultContent": "",
                    "bSortable": false,
                    "bSearchable": false,
                    "fnRender": function(oObj) {
                        console.log()
						return oObj.aData.drv_id;
                    }
                },
				{
                    "mDataProp": null,
                    "sClass": "sno",
					"sDefaultContent": "",
                    "fnRender": function(oObj) {
                        
						if($.inArray('2',oObj.aData.doc_status_id) > -1 == true)
						{
							status="<span class='reject'>Rejected</span>";
						}
						else if($.inArray('3',oObj.aData.doc_status_id) > -1 == true)
						{
							status="<span class='pending'>Pending</span>";
						}
						else if($.inArray('1',oObj.aData.doc_status_id) > -1 == true)
						{
							status="<span class='accept'>Active</span>";
						}
						return status;
                    }
                },
				{
                    "mDataProp": null,
                    "sDefaultContent": "",
                    "fnRender": function(oObj) {
                        return oObj.aData.fname+" "+oObj.aData.mname+" "+oObj.aData.lname;
                    }
                },
				{
                    "mDataProp": null,
                    "sDefaultContent": "",
                    "fnRender": function(oObj) {
                        
						if(oObj.aData.passed == 1) // test result  status
							var test_result="Passed";
						
						else if(oObj.aData.passed == 0)
							var test_result="Failed";
		
						else
							var test_result="Not Attempted"; // end of test result  status
						
						return test_result;
                    }
                },
				{
                    "mDataProp": null,
                    "sDefaultContent": "",
                    "fnRender": function(oObj) {
                        if(oObj.aData.active==1)
					   {
						   return '<span class="hide">1</span>'+
						   '<div class="can-toggle">'+ 
						   '<input id='+oObj.aData.drv_id+' class="drv_checkbox" type="checkbox" value="1" checked>'+
						   ' <label for='+oObj.aData.drv_id+'>'+
							'<div class="can-toggle__switch" data-checked="Active" data-unchecked="De-Active"></div></label></div>';
							
							
	
					   }
					   else
					   {
						   return '<span class="hide">0</span>'+
						   '<div class="can-toggle">'+ 
						   '<input id='+oObj.aData.drv_id+' class="drv_checkbox" type="checkbox" value="0">'+
						   ' <label for='+oObj.aData.drv_id+'>'+
							'<div class="can-toggle__switch" data-checked="Active" data-unchecked="De-Active"></div></label></div>';
							
							
	
					   }	  
                    }
                }
			],
		//"ajax": "<?php echo site_url(); ?>/admin_ptr_view/get_ptr"
		
		"fnInitComplete": function() {
                //this.fnAdjustColumnSizing();
                $('div.dataTables_filter input').focus();

                jQuery('#datatable .group-checkable').change(function() {
                    var set = jQuery(this).attr("data-set");
                    var checked = jQuery(this).is(":checked");
                    jQuery(set).each(function() {
                        if (checked) {
                            $(this).attr("checked", true);
                        } else {
                            $(this).attr("checked", false);
                        }
                    });
                    jQuery.uniform.update(set);
                });

				 jQuery('#datatable_wrapper .dataTables_filter').addClass("input-group");
                jQuery('#datatable_wrapper .dataTables_filter input').addClass("input-sm form-control"); // modify table search input
                jQuery('#datatable_wrapper .dataTables_length select').addClass("m-wrap xsmall"); // modify table per page dropdown
            }
    }); //end of data table
	
          

	
		
		 $("body").on('click','#datatable tbody .sno', function() {
			/*
			var ttr=$(this);
		  var drv_id=$(this).prop("id");
			alert(drv_id);
			$.ajax
			({
				url: "<?php echo site_url(); ?>/su/admin_ptr_view/GetDrvDocs",   	// Url to which the request is send
				type: "POST",      				// Type of request to be send, called as method
				dataType: "JSON",
				data: 'drv_id='+drv_id, 		// Data sent to server, a set of key/value pairs representing form fields and values 
				success: function(json)  		// A function to be called if request succeeds
				{
					
				*/	
					var nTr = $(this).parents('tr')[0];
				//alert(nTr)	
					if (mTable.fnIsOpen(nTr)) { //This row is already open - close it 
					mTable.fnClose(nTr);
					} else {  //Open this row 
						mTable.fnOpen(nTr, fnFormatDetails(mTable, nTr), 'details' );

					//mTable.fnOpen(nTr, fnFormatDetails(json), 'details' );
					}
					
				//}
			
			//}) //ajax end
		  })
	 $('body').on('change','input:radio',function(){ // change status of docs
 	var rad_val=$(this).val();
	var rad_class=$(this).prop('class');
	var RDt=$(this).prop('id');
	check=$(this);
		var reg_date=RDt.split('_');
	//alert(reg_date[1])
	//alert(rad_val);
	//alert(rad_class);
	if(rad_val == 2)
	{
		swal({   title: "Reason!",   text: "Write Reason:",   type: "input",   showCancelButton: true,   closeOnConfirm: false,   animation: "slide-from-top",   inputPlaceholder: "Write Reason" },
			function(inputValue){
			if (inputValue === false)
			{
				mTable.fnDraw();
				//check.attr('checked','checked');
				//check.prop('checked', true);
				return false;
			
			}
			if (inputValue === "")
			{  
				swal.showInputError("You need to write Reason!");
				mTable.fnDraw();
				//check.attr('checked','checked');
				
				//check.prop('checked', true);
				return false 
			} 
			else
			{
				
				$.ajax({
					url: "<?php echo site_url(); ?>/su/admin_ptr_view/drv_change_status",   	// Url to which the request is send
					type: "POST",      				// Type of request to be send, called as method
					data: 'rad_val='+rad_val+'&rad_class='+rad_class+'&reason='+inputValue+'&reg_date='+reg_date[1], 		// Data sent to server, a set of key/value pairs representing form fields and values 
					//beforeSend:function(){ $('.loader').show(); },
					//complete:function(){ $('.loader').hide(); },	
					success: function(data)  		// A function to be called if request succeeds
					{
						if(data == '200')
						{
							
							swal({   title: "Successful",   text: "Successfully change status of documents",   type: "success",   confirmButtonText: "OK" },
								function (isConfirm){ 
									mTable.fnDraw();

								});
						}
						
						else
						{
							swal({   title: "Error!",   text: "some problems have been occured",   type: "error",   confirmButtonText: "OK" });
						}
					},		
		
				})
				//swal("Nice!", "You wrote: " + inputValue, "success");
			}
		});
	}
	else
	{
		$.ajax({
					url: "<?php echo site_url(); ?>/su/admin_ptr_view/drv_change_status",   	// Url to which the request is send
					type: "POST",      				// Type of request to be send, called as method
					data: 'rad_val='+rad_val+'&rad_class='+rad_class, 		// Data sent to server, a set of key/value pairs representing form fields and values 
					//beforeSend:function(){ $('.loader').show(); },
					//complete:function(){ $('.loader').hide(); },	
					success: function(data)  		// A function to be called if request succeeds
					{
						if(data == '200')
							swal({   title: "Successful",   text: "Successfully change status of documents",   type: "success",   confirmButtonText: "OK" },
								function (isConfirm){ 
									mTable.fnDraw();

								});
						else
							swal({   title: "Error!",   text: "some problems have been occured",   type: "error",   confirmButtonText: "OK" });
				},		
		
				})
		
	}
	
 }) // end status of docs	 
		  
	
// change main status of driver
$('body').on('change','.drv_checkbox',function(){
	//alert("hi")
	//exit;
	
	var chk_val=$(this).val();
	var myString=$(this).prop('id');
	var chk_drv_id= myString.replace('a', '');
	var check=$(this);
	//alert(chk_val);
			//$(this).prop('checked', false);

	
	swal({
			title: "Are you sure?",
			text: "You want to change your status!",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Yes, change it!",
			cancelButtonText: "No, cancel please!",
			closeOnConfirm: false,
			closeOnCancel: false 
			},
	function(isConfirm){
	if (isConfirm) 
	{
	$.ajax({
		url: "<?php echo site_url(); ?>/su/admin_ptr_view/drv_main_status",   	// Url to which the request is send
		type: "POST",      				// Type of request to be send, called as method
		data: 'chk_val='+chk_val+'&chk_drv_id='+chk_drv_id, 		// Data sent to server, a set of key/value pairs representing form fields and values 
		success: function(data)  		// A function to be called if request succeeds
	    {
	if(data == '1')
	{		
		swal({   title: "Successful",   text: "This Driver is successfully activated",   type: "success",   confirmButtonText: "OK" },
		function (isConfirm){ //window.location="<?php echo site_url('su/admin_ptr_view');?>" 
			//check.prop('checked', true);
				mTable.fnDraw();

		//oTable.fnClearTable(0);
		});
	}
	else if(data == '2')
	{

		swal({   title: "Error!",   text: "Driver is not activated because all Driver documents required to be active",   type: "error",   confirmButtonText: "OK" },
		
		function (isConfirm){ //window.location="<?php echo site_url('su/admin_ptr_view');?>" 
				
				//check.prop('checked', false);
				mTable.fnDraw();

		//oTable.fnClearTable(0);
		});
	}	
	else if(data == '3')
	{
		swal({   title: "Successful",   text: "This Driver is successfully de-activated",   type: "success",   confirmButtonText: "OK" },
		
		function (isConfirm){ //window.location="<?php echo site_url('su/admin_ptr_view');?>" 
				
				//check.prop('checked', false);
				mTable.fnDraw();

		//oTable.fnClearTable(0);
		});
	}
	//alert(data)
	},
	//async:false
	
	})
	
	}
	else {
							 
			swal("Cancelled", "Status is not changed ", "error");
					mTable.fnDraw();

		}
	 }
		
	);
	return false;
	//alert(a)
 })	
 //end main status

 
 $("body").on('change','#select_drv_status',function(){
	
	    var choosedFilter = $(this).val();
    
    mTable.fnFilter(choosedFilter,1,true,false);
	
	
})
 $("body").on('change','#select_test_status',function(){	
	    var choosedFilter = $(this).val();
    
    mTable.fnFilter(choosedFilter,2,true,false);
	
	
})
 $("body").on('change','#select_ActDeact_status',function(){
	
	    var choosedFilter = $(this).val();
    
    mTable.fnFilter(choosedFilter,3,true,false);
	
})
 
})// end of document ready function		

	
		  
		  
				
			
			
		 function fnFormatDetails(mTable,nTr)
		{
			//for(var i=0;i<json.length;i++){
			var oData = mTable.fnGetData(nTr);
			var st_name;
			var st_class;
			var sOut;
			var a;
			
			//exit;
			//alert(json)
			//var temp=Array();
			var temp=oData.name.split(",");
			var up_id=oData.drv_doc_upload_id.split(",");
			var status_id=oData.doc_status_id.split(",");
			
			
			
			
			
				
						
				 sOut = '<tr>'+
					'<td class="table-extend" colspan="4" style="border:none;">'+
					'<a href="image_large_view.html" data-toggle="ajaxModal" >'+
					'<img class="img-circle" src="data:image/jpg;base64,'+oData.drv_pic+'"  width="112" height="112">'+ 
					'<h4>Additional information</h4>'+
					'<ul class="ul_inform">'+
					'<li><label><a href="#">Email:</a> <span class="li_td">'+oData.email+'</span></label></li>'+
                    <!--<li><label><a href="#">Password:</a> <span class="li_td">*****</span></label></li>-->
                    '<li><label><a href="#">Date of Birth:</a> <span class="li_td">'+oData.dob+'</span></label></li>'+
                    '<li><label><a href="#">Mobile:</a> <span class="li_td">'+oData.mobile+'</span></label></li>'+
                    '<li><label><a href="#">License Number:</a> <span class="li_td">'+oData.lic_no+'</span></label></li>'+
                    '<li><label><a href="#">Address:</a> <span class="li_td">'+oData.address+'</span></label></li>'+
                    '<li><label><a href="#">Reg.Date:</a> <span class="li_td">'+oData.reg_date+'</span></label></li>'+
                    '<br><br>';
					
				for(a=0; a < temp.length; ++a )
				{
					//alert(oData.doc_status_id)
					if(oData.doc_status_id=='1'){
							st_class='accept';
							st_name='Active';
					}
					else if(oData.doc_status_id=='2'){
							st_class='reject';
							st_name='Rejected';
						}
					
					else {
							st_class='pending';
							st_name='Pending';
						}
					
					if(status_id[a] == 1)
					{	
					sOut +='<div class="col-md-12">'+
                    '<li><a class="bton btn-dwn" href="#">'+
					'<i class="fa fa-cloud-download"></i>&nbsp;&nbsp;'+temp[a]+'</a>'+
					'<span class="label bg-'+st_class+'" id="status_id1">'+st_name+'</span>'+
					'<br><br>'+
					'<div class="switch-toggle switch-3 switch-ios">'+
					
					
					'<input id="a'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="1" checked >'+
					'<label class="blue" for="a'+up_id[a]+'">Accept</label>'+
					
					'<input id="p'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" disabled value="3">'+
					'<label class="red" for="p'+up_id[a]+'" onclick="">Pending</label>'+
					
					'<input id="r'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="2">'+
					'<label class="green" for="r'+up_id[a]+'" onclick="">Reject</label>';
					}	
					if(status_id[a] == 2)
					{	
					sOut +='<div class="col-md-12">'+
                    '<li><a class="bton btn-dwn" href="#">'+
					'<i class="fa fa-cloud-download"></i>&nbsp;&nbsp;'+temp[a]+'</a>'+
					'<span class="label bg-'+st_class+'" id="status_id1">'+st_name+'</span>'+
					'<br><br>'+
					'<div class="switch-toggle switch-3 switch-ios">'+
					
					
					'<input id="a'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="1">'+
					'<label class="blue" for="a'+up_id[a]+'">Accept</label>'+
					
					'<input id="p'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" disabled value="3">'+
					'<label class="red" for="p'+up_id[a]+'" onclick="">Pending</label>'+
					
					'<input id="r'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="2"  checked >'+
					'<label class="green" for="r'+up_id[a]+'" onclick="">Reject</label>';
					}
					else if(status_id[a] == 3){	
					sOut +='<div class="col-md-12">'+
                    '<li><a class="bton btn-dwn" href="#">'+
					'<i class="fa fa-cloud-download"></i>&nbsp;&nbsp;'+temp[a]+'</a>'+
					'<span class="label bg-'+st_class+'" id="status_id1">'+st_name+'</span>'+
					'<br><br>'+
					'<div class="switch-toggle switch-3 switch-ios">'+
					
					
					'<input id="a'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="1" >'+
					'<label class="blue" for="a'+up_id[a]+'">Accept</label>'+
					
					'<input id="p'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" disabled value="3"  checked>'+
					'<label class="red" for="p'+up_id[a]+'" onclick="">Pending</label>'+
					
					'<input id="r'+up_id[a]+'" class="'+up_id[a]+'" name="as'+up_id[a]+'" type="radio" value="2">'+
					'<label class="green" for="r'+up_id[a]+'" onclick="">Reject</label>';
					}	
					
			
			
			}
			return sOut;
		}	
	
    </script> 
    
    
     
<!--end theme js-->
  
